package org.example;

import java.time.LocalDate;

public class Livro {

    private String nome;
    private LocalDate dataEntrada;
    private Double saldo;


    public Livro(String nome, LocalDate dataEntrada, Double saldo) {
        this.nome = nome;
        this.dataEntrada = dataEntrada;
        this.saldo = 0.0;
    }


    public void incluir(double valor) {
        if (valor <= 0) {
            throw new IllegalArgumentException("O valor do incluir deve ser maior que zero.");
        }
        if (dataEntrada.isAfter(LocalDate.now())){
            throw new IllegalArgumentException("Entrada não podem ser em data futura.");
        }
        this.saldo += valor;
    }

    public void retirar(double valor) {
        if (valor <= 0) {
            throw new IllegalArgumentException("O valor de retirar deve ser maior que zero.");
        }
        if (valor > this.saldo) {
            throw new IllegalArgumentException("Saldo insuficiente para esta retirda.");
        }
        this.saldo -= valor;
    }

    // testar se saldo foi alterado para mais
    // testar se saldo foi alterado para menos
    // testar se saldo aceita estar negativo
    // testar se saldo aceita somar valor negativo alterando somar para diminuir
    // testar se data aceita informar datas no futuro.

    public String getNome() {
        return nome;
    }

    public LocalDate getDataLancamento() {
        return dataEntrada;
    }

    public Double getSaldo() {
        return saldo;
    }



}
